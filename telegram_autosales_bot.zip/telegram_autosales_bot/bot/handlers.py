
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart

from .keyboards import catalog_keyboard
from .products import PRODUCTS
from .payments import create_crypto_invoice

router = Router()

@router.message(CommandStart())
async def start(message: Message):
    await message.answer(
        "Добро пожаловать в магазин цифровых товаров",
        reply_markup=catalog_keyboard()
    )

@router.callback_query(F.data.startswith("buy_"))
async def buy_product(callback: CallbackQuery):
    product_id = int(callback.data.split("_")[1])

    product = next(
        (p for p in PRODUCTS if p["id"] == product_id),
        None
    )

    if not product:
        await callback.message.answer("Товар не найден")
        return

    invoice = await create_crypto_invoice(product["price"])

    if invoice.get("ok"):
        pay_url = invoice["result"]["pay_url"]

        await callback.message.answer(
            f"Оплатите товар: {product['title']}\n\n"
            f"Сумма: ${product['price']}\n\n"
            f"Ссылка на оплату:\n{pay_url}"
        )
    else:
        await callback.message.answer("Ошибка создания счета")
