
from aiogram.utils.keyboard import InlineKeyboardBuilder
from .products import PRODUCTS

def catalog_keyboard():
    builder = InlineKeyboardBuilder()

    for item in PRODUCTS:
        builder.button(
            text=f"{item['title']} - ${item['price']}",
            callback_data=f"buy_{item['id']}"
        )

    builder.adjust(1)
    return builder.as_markup()
