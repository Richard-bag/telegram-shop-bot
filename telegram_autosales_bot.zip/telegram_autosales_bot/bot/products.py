
PRODUCTS = [
    {
        "id": 1,
        "title": "Цифровой товар #1",
        "price": 5,
        "description": "Описание товара",
        "file": "goods/item1.txt"
    },
    {
        "id": 2,
        "title": "Цифровой товар #2",
        "price": 15,
        "description": "Описание товара",
        "file": "goods/item2.txt"
    }
]
