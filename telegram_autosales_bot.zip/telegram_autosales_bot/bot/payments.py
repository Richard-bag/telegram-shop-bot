
import aiohttp
import os

CRYPTOBOT_TOKEN = os.getenv("CRYPTOBOT_TOKEN")

async def create_crypto_invoice(amount: int):
    url = "https://pay.crypt.bot/api/createInvoice"

    headers = {
        "Crypto-Pay-API-Token": CRYPTOBOT_TOKEN
    }

    payload = {
        "asset": "USDT",
        "amount": amount
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(url, json=payload, headers=headers) as resp:
            data = await resp.json()
            return data

# Заглушка для AvtoBys кошелька
async def create_avtobys_invoice(amount: int):
    return {
        "pay_url": "https://example.com/pay"
    }
