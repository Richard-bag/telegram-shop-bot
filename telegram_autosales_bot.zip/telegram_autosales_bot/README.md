
# Telegram Auto Sales Bot

Готовый Telegram-бот для продажи цифровых товаров.

## Стек
- Python 3.11
- aiogram 3
- SQLite
- Docker

## Возможности
- Каталог товаров
- Автовыдача цифрового товара
- Оплата через CryptoBot
- Поддержка второго платежного шлюза (заглушка под AvtoBys кошелек)
- Админ-панель
- Логи продаж

## Установка

### 1. Установить зависимости
```bash
pip install -r requirements.txt
```

### 2. Создать бота
Создай бота через @BotFather

### 3. Заполнить .env
```env
BOT_TOKEN=YOUR_BOT_TOKEN
CRYPTOBOT_TOKEN=YOUR_CRYPTOBOT_API_TOKEN
ADMIN_ID=123456789
```

### 4. Запуск
```bash
python main.py
```

## Docker
```bash
docker build -t autosales-bot .
docker run -d autosales-bot
```

## Как добавлять товары

В файле:
`bot/products.py`

Пример:
```python
PRODUCTS = [
    {
        "id": 1,
        "title": "Товар 1",
        "price": 10,
        "file": "goods/item1.txt"
    }
]
```
